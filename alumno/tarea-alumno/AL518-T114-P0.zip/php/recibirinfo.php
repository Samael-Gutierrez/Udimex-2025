<?php

$name = $_POST['nombre'];
$years = $_POST['edad'];

echo "El nombre de usuario es: " . $name . " y su edad es: " . $years . "años.";