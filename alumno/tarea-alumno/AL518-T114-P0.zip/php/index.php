<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="recibirinfo.php" method="POST">
        <hr>
        <label>Nombre:</label>
        <input type="text" placeholder="Coloca tu nombre" maxlength="30" name="nombre"><br>
        <label>Edad:</label>
        <input type="number" placeholder="Coloca tu edad" min="0" max="150" step="1" maxlength="3" name="edad"><br>
        <input type="submit" value="Enviar">
        <hr>
    </form>
</body>
</html>